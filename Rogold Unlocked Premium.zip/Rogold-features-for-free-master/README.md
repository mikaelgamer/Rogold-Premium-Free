# Rogold-features-for-free

rogold features for free, that's it lmao


## installation 
**FEB 2nd 2023 update**

in order to install, you must first download it through Code -> download zip![image](https://user-images.githubusercontent.com/98064246/216500002-f94773f5-d6ec-408b-9d49-4f6ae2df6fda.png)

Extract the file and once it's over with, go to chrome://extensions/ and select "Developer Mode" at the top right hand corner. ![image](https://user-images.githubusercontent.com/98064246/216500184-30ece871-a6fd-4d40-938f-86032bc18218.png)

When you do press "Load unpacked" at the top and select the extracted folder! ![image](https://user-images.githubusercontent.com/98064246/216500286-49177dfd-c432-4d4d-9d8a-431e006ea470.png)

Now go for where its the rogold extension with "(FREE)"![image](https://user-images.githubusercontent.com/98064246/216500698-ac80e4d0-eace-4685-87a5-a5d31d053fd9.png)
Enable it, and there you go! Make sure to disable the other rogold and there u go. Feel free to star this repo if you like this. Cya
