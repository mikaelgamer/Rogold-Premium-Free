class ByteReader extends Uint8Array {

}